export * as gateway from "./gatewayResponse";
