export * from "./getConfig";
export * from "./IAppTypes";
