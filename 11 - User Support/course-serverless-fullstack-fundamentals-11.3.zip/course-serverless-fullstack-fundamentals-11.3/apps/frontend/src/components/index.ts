export * from "./ConfigureAmplifyClientSide";
