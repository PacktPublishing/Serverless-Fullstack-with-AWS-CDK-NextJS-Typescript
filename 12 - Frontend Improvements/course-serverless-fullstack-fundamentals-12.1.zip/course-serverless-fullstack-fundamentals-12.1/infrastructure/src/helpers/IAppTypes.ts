export type IAppConfig = {
  awsAccountId: string;
  awsRegion: string;
  domain: string;
  apiSubdomain: string;
  webSubdomain: string;
};
