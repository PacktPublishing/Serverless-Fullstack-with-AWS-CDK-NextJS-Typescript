export * from "./useTranslate";
