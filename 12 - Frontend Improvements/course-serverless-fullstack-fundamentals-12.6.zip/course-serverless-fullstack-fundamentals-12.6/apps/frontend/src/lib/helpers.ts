export const emptyPromise = new Promise((accent, reject) => {});
